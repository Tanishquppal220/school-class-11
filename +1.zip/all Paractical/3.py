a=int(input("Enter the first Number"))
b=int(input("Enter the Second Number"))
c=int(input("Enter the third Number"))
if a>b and a>c: 
    print(a,"is greatest") 
elif b>a and b>c: 
    print(b,"is greatest") 
else: 
    print(c,"is greatest") 