import math

x = int(input("Enter the value of x: "))
n = int(input("Enter the value of n: "))
sum=0
for i in range(1, n + 1):
    term = x ** i / math.factorial(i)
    sum +=term
print("Sum =", sum)

