a = int(input("Enter the number:"))
for i in range(65,65+a):
    print(chr(i))
    i=i+1